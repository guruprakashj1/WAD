1.	HTML5 Basics and Basic Tags
•	Introduction to HTML5
•	Document structure
•	Basic HTML tags (e.g., <html>, <head>, <body>)
•	Text formatting tags (e.g., <h1>-<h6>, <p>, <strong>, <em>)
•	Hyperlinks (e.g., <a>)
